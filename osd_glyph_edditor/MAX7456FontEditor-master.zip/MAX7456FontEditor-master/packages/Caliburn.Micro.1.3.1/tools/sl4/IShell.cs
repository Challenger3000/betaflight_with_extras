﻿namespace $safeprojectname$ {
    public interface IShell {}
}