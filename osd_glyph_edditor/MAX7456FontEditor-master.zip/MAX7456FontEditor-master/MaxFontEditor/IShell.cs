﻿namespace MaxFontEditor {
    public interface IShell {}
}
